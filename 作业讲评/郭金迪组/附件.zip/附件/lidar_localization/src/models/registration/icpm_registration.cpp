/*
 * @Description: ICP 匹配模块
 * @Author: Ren Qian
 * @Date: 2020-02-08 21:46:45
 */
#include "lidar_localization/models/registration/icpm_registration.hpp"
#include <pcl/io/pcd_io.h>
#include <pcl/point_cloud.h>
#include <pcl/point_types.h>  
#include <pcl/kdtree/kdtree_flann.h>
#include <pcl/filters/filter.h>
#include <pcl/registration/icp.h>
#include "glog/logging.h"

namespace lidar_localization {
ICPMRegistration::ICPMRegistration(const YAML::Node& node) {
    
    float n_iters = node["n_iters"].as<float>();
    float epsilon = node["epsilon"].as<float>();
    float min_err = node["min_err"].as<float>();

    ICPMRegistration::SetRegistrationParam(n_iters,epsilon,min_err);
}

ICPMRegistration::ICPMRegistration(float n_iters,float epsilon,float min_err) {

	ICPMRegistration::SetRegistrationParam(n_iters, epsilon, min_err);
}

bool ICPMRegistration::SetRegistrationParam(float n_iters,float epsilon,float min_err) {

    ICPMRegistration::n_iters_ = n_iters;
    ICPMRegistration::epsilon_ = epsilon;
    ICPMRegistration::min_err_ = min_err;
	LOG(INFO) << "ICPM 的匹配参数为：" << std::endl
              << "n_iters: " << n_iters << ", "
              << "epsilon: " << epsilon << ", "
              << "min_err: " << min_err << ", "
              << std::endl << std::endl;

    return true;
}

inline std::vector<cv::Point3f> ICPMRegistration:: cloud2vector(int N,CloudData::CLOUD cloud){
  std::vector<cv::Point3f> cloud_;
  for (int i=0;i<N;i++){

    if (! pcl_isfinite ((cloud)[i].x))
    {
      continue;
    }

    cloud_.push_back(cv::Point3f(cloud[i].x,cloud[i].y,cloud[i].z));
  }
  //std::cout<<"finishing trans"<<std::endl;
  return cloud_;
}

bool ICPMRegistration::SetInputTarget(const CloudData::CLOUD_PTR& input_target) {

    
	

	N1=input_target->size();
	// input_target_=input_target;
	match_cloud1=cloud2vector(N1,*input_target);
	std::cout<<"N1="<<match_cloud1.size()<<std::endl;

    return true;
}

bool ICPMRegistration::ScanMatch(const CloudData::CLOUD_PTR& input_source, 
                                const Eigen::Matrix4f& predict_pose, 
                                CloudData::CLOUD_PTR& result_cloud_ptr,
                                Eigen::Matrix4f& result_pose) {

	N2=input_source->size();
    match_cloud2=cloud2vector(N2,*input_source);
	std::cout<<"N2="<<match_cloud2.size()<<std::endl;
	Eigen::Matrix3d R_;
    Eigen::Vector3d t_;
    findTransformation ( match_cloud1, match_cloud2, 
	ICPMRegistration::n_iters_, ICPMRegistration::epsilon_, ICPMRegistration::min_err_, R_, t_ );
    result_pose<<(float)R_(0,0),(float)R_(0,1),(float)R_(0,2),(float)t_(0),
     (float)R_(1,0),(float)R_(1,1),(float)R_(1,2),(float)t_(1),
     (float)R_(2,0),(float)R_(2,1),(float)R_(2,2),(float)t_(2),
     0.0,0.0,0.0,1.0;

    Eigen::Affine3f t;
    t.matrix() = result_pose;
	std::cout<<"result_pose="<<t.matrix()<<std::endl;
    pcl::transformPointCloud(*input_source,*result_cloud_ptr,t); 


    return true;
}



void ICPMRegistration::findTransformation ( const std::vector< cv::Point3f >& pts_model, const std::vector< cv::Point3f >& pts_cloud,
float &n_iters,  float &epsilon,  float &min_err, Eigen::Matrix3d &R, Eigen::Vector3d &t )
{
	const double min_err2 = min_err * min_err;
	const double factor = 9.0;
	const int step =1;
	// // two vectors for matched points.
     std::vector<cv::Point3f> pts_cloud_matched;
     std::vector<cv::Point3f> pts_model_matched;

    // construct kd-tree for model cloud.
    pcl::PointCloud<pcl::PointXYZ>::Ptr model_cloud ( new pcl::PointCloud<pcl::PointXYZ> );
    for ( size_t i = 0; i < pts_model.size(); ++i ) {
        cv::Point3f ptm = pts_model[i];
        pcl::PointXYZ pt ( ptm.x, ptm.y, ptm.z );
        model_cloud->push_back ( pt );
    }

	pcl::KdTreeFLANN<pcl::PointXYZ>* kd_tree = new pcl::KdTreeFLANN <pcl::PointXYZ>();
 	kd_tree->setInputCloud ( model_cloud );

	// used for search.
	std::vector <int> index (1);
	std::vector <float> squared_distance (1);

	
		// clear two point clouds.
		pts_cloud_matched.clear();
		pts_model_matched.clear();
        // step 1. construct matched point clouds.
		
		for ( int i = 0; i <pts_cloud.size(); i += step ) {	
            // find the nearest points
			// searchPoint.x = pts_cloud[i][0];
        	// searchPoint.y = pts_cloud[i][1];
        	// searchPoint.z = pts_cloud[i][2];
			pcl::PointXYZ searchPoint(pts_cloud[i].x, pts_cloud[i].y, pts_cloud[i].z);
			int num = kd_tree->nearestKSearch(searchPoint, 1, index, squared_distance);
        	if (num > 0)
        		{
            	if (sqrt(squared_distance[0])<0.1)
            	{
				pts_cloud_matched.push_back(pts_cloud.at(i));
				pts_model_matched.push_back(pts_model.at(index[0]));
				}
        	} 
		}
		int N_=pts_cloud_matched.size();
        std::cout<<"match_size="<<N_<<std::endl;

        //std::cout << "iter:" << n << " mathced size: " << pts_model_matched.size() << " " << pts_cloud_matched.size() << std::endl;
        // step 2. Get R and t.
        // step 2.1 find centor of model(X) and cloud(P)
        cv::Point3f mu_x;
		cv::Point3f mu_p;
        for(int j = 0; j < N_; j ++)
		{
			mu_x += pts_model_matched[j];
			mu_p += pts_cloud_matched[j];
		}
        mu_x = mu_x / N_;
		mu_p = mu_p / N_;
		std::cout<<"MU_X="<<mu_x<<"\nMU_p="<<mu_p<<std::endl;
		std::vector<cv::Point3f>     q1 ( N_ ), q2 ( N_ ); // remove the center
    	for ( int m=0; m<N_; m++ )
    	{
        	q1[m] = pts_model_matched[m] - mu_x;
        	q2[m] = pts_cloud_matched[m] - mu_p;
    	}
		// step 2.2 Get W.
		Eigen::Matrix3d W;
		for(int l = 0; l < N_;l ++)
		{
			 W = W+ Eigen::Vector3d ( q1[l].x, q1[l].y, q1[l].z ) * Eigen::Vector3d ( q2[l].x, q2[l].y, q2[l].z ).transpose();
		}
		
		// step 2.3 Get R
		Eigen::JacobiSVD<Eigen::Matrix3d> svd(W, Eigen::ComputeFullU | Eigen::ComputeFullV);
		Eigen::Matrix3d U = svd.matrixU();
    	Eigen::Matrix3d V = svd.matrixV();
		    if (U.determinant() * V.determinant() < 0)
    {
        for (int x = 0; x < 3; ++x)
        {
            U(x, 2) *= -1;
        }
    }
		R = U* ( V.transpose() );
		// step 2.4 Get t
		t  = Eigen::Vector3d ( mu_x.x, mu_x.y, mu_x.z ) - R * Eigen::Vector3d ( mu_p.x, mu_p.y, mu_p.z );
		std::cout<<"R="<<R<<"\nt="<<t<<std::endl;	
    } // for n_iters
 
}




