/*
 * @Description: ICP 匹配模块
 * @Author: Ren Qian
 * @Date: 2020-02-08 21:46:45
 */
#include "lidar_localization/models/registration/icp_registration.hpp"

#include "glog/logging.h"

namespace lidar_localization {

ICPRegistration::ICPRegistration(const YAML::Node& node)
    :icp_ptr_(new pcl::IterativeClosestPoint<CloudData::POINT, CloudData::POINT>()) {
    
    float MaxCorrespondenceDistance = node["MaxCorrespondenceDistance"].as<float>();
    float TransformationEpsilon = node["TransformationEpsilon"].as<float>();
    float EuclideanFitnessEpsilon = node["EuclideanFitnessEpsilon"].as<float>();
    int MaximumIterations = node["MaximumIterations"].as<int>();

    ICPRegistration::SetRegistrationParam(MaxCorrespondenceDistance, TransformationEpsilon, EuclideanFitnessEpsilon, MaximumIterations);
}

ICPRegistration::ICPRegistration(float MaxCorrespondenceDistance, float TransformationEpsilon,float EuclideanFitnessEpsilon, int MaximumIterations)
    :icp_ptr_(new pcl::IterativeClosestPoint<CloudData::POINT, CloudData::POINT>()) {

    ICPRegistration::SetRegistrationParam(MaxCorrespondenceDistance, TransformationEpsilon, EuclideanFitnessEpsilon, MaximumIterations);
}

bool ICPRegistration::SetRegistrationParam(float MaxCorrespondenceDistance, float TransformationEpsilon,float EuclideanFitnessEpsilon, int MaximumIterations) {
    icp_ptr_->setMaxCorrespondenceDistance(MaxCorrespondenceDistance);  
    icp_ptr_->setTransformationEpsilon(TransformationEpsilon); 
    icp_ptr_->setEuclideanFitnessEpsilon(EuclideanFitnessEpsilon); 
    icp_ptr_->setMaximumIterations (MaximumIterations); 

    LOG(INFO) << "ICP 的匹配参数为：" << std::endl
              << "MaxCorrespondenceDistance: " << MaxCorrespondenceDistance << ", "
              << "TransformationEpsilon: " << TransformationEpsilon << ", "
              << "EuclideanFitnessEpsilon: " << EuclideanFitnessEpsilon << ", "
              << "MaximumIterations: " << MaximumIterations 
              << std::endl << std::endl;

    return true;
}

bool ICPRegistration::SetInputTarget(const CloudData::CLOUD_PTR& input_target) {
    icp_ptr_->setInputTarget(input_target);

    return true;
}

bool ICPRegistration::ScanMatch(const CloudData::CLOUD_PTR& input_source, 
                                const Eigen::Matrix4f& predict_pose, 
                                CloudData::CLOUD_PTR& result_cloud_ptr,
                                Eigen::Matrix4f& result_pose) {
    icp_ptr_->setInputSource(input_source);
    icp_ptr_->align(*result_cloud_ptr, predict_pose);
    result_pose = icp_ptr_->getFinalTransformation();

    return true;
}
}