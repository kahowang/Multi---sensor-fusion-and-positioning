/*
 * @Description: ICP-M 匹配模块
 * @Author: Ren Qian
 * @Date: 2020-02-08 21:46:57
 */
#ifndef LIDAR_LOCALIZATION_MODELS_REGISTRATION_ICPM_REGISTRATION_HPP_
#define LIDAR_LOCALIZATION_MODELS_REGISTRATION_ICPM_REGISTRATION_HPP_
#include <opencv2/core/core.hpp>
#include <opencv2/opencv.hpp>
#include "lidar_localization/models/registration/registration_interface.hpp"

namespace lidar_localization {
class ICPMRegistration: public RegistrationInterface {
  public:
    ICPMRegistration(const YAML::Node& node);
    ICPMRegistration(float n_iters,float epsilon,float min_err);  
    bool SetInputTarget(const CloudData::CLOUD_PTR& input_target) override;
    bool ScanMatch(const CloudData::CLOUD_PTR& input_source, 
                   const Eigen::Matrix4f& predict_pose, 
                   CloudData::CLOUD_PTR& result_cloud_ptr,
                   Eigen::Matrix4f& result_pose) override;
  
  private:
    bool SetRegistrationParam(float n_iters,float epsilon,float min_err);
  public:
    float n_iters_=100;
    float epsilon_=1.0e-10;
    float min_err_=0.001;
    std::vector<cv::Point3f> match_cloud1;std::vector<cv::Point3f> match_cloud2;
    int N1=0;int N2=0;  
    // CloudData::CLOUD_PTR input_target_;
    inline std::vector<cv::Point3f> cloud2vector(int N,CloudData::CLOUD cloud);
    void findTransformation ( const std::vector< cv::Point3f >& pts_model, const std::vector< cv::Point3f >& pts_cloud, float &n_iters, float &epsilon, float &min_err, Eigen::Matrix3d &R, Eigen::Vector3d &t );


};

}

#endif



